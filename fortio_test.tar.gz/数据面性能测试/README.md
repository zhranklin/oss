# 数据面性能测试

数据面相关测试实际上也是基于istio执行的, 使用istioctl进行sidecar注入, 使用mixer进行遥测。测试相关脚本位于[当前目录](.)

以下测试工作基于该目录进行

## 环境准备

```shell
export NAMESPACE=twopods #或者换成别的名字
DNS_DOMAIN=your_domain ./setup_test.sh
```

通过`kubectl`命令检查相应的pod是否已启动, 如已启动, 就可以开始基准测试了

## 启动基准测试

```shell
python runner/runner.py 16,64 1000,4000 180 --serversidecar --baseline
```

## 基准测试参数说明

`--serversidecar` `--baseline`分别表示加入仅server端加入sidecar、无sidecar的场景, 而该脚本默认还执行client、server端均加入sidecar的场景

runner.py脚本的前三个参数分别表示连接数、qps、测试持续时间, 逗号分隔值表示多种情况的正交测试

例如上述的命令会对两种连接数、两种qps、三种sidecar部署方式执行`2*2*3=12`次测试, 每次测试持续3分钟

**注: 官方基准测试的场景是16连接、1000qps**

fortioclient

## 获取时延数据图表
时延数据位于fortioclient的pod上, 可以进行端口转发(至18080)获取数据:

```shell
kubectl port-forward $(kubectl get pod -n $NAMESPACE -l app=fortioclient -o jsonpath='{.items[0].metadata.name}') 18080:8080
```

再通过浏览器访问`http://宿主机ip:18080`即通过访问fortio可获取时延数据的图表

![](./media/fortio_page.png)

## 获取时延+mixer性能数据
首先对prometheus进行端口转发:

```shell
kubectl port-forward $(kubectl get pod -n istio-system -l app=prometheus -o jsonpath='{.items[0].metadata.name}') 19090:9090
```

执行以下命令:

```shell
python3 ./runner/fortio.py http://localhost:18080 http://localhost:19090 --csv StartTime,ActualDuration,Labels,NumThreads,ActualQPS,p50,p90,p99,cpu_mili_avg_telemetry_mixer,cpu_mili_max_telemetry_mixer,mem_MB_max_telemetry_mixer,cpu_mili_avg_fortioserver_deployment_proxy,cpu_mili_max_fortioserver_deployment_proxy,mem_MB_max_fortioserver_deployment_proxy,cpu_mili_avg_ingressgateway_proxy,cpu_mili_max_ingressgateway_proxy,mem_MB_max_ingressgateway_proxy
```

执行过程中可能提示某些python依赖没安装, 就用pip命令先安装一下

执行结束后, 提示将数据写到了哪个文件:

```shell
Wrote 15 records to /tmp/tmp5zhsy1yy
Wrote 15 records to /tmp/tmpd2eios8q
```

这两个文件分别是csv、json格式, 里面包含了所需的数据, 可导入到excel进行分析

![](./media/benchmark_csv.png)

## mixer遥测相关测试
由于mixer与sidecar执行的rps相关, 故将mixer相关指标放在数据面进行测试

在部署istio时打开mixer遥测即可, 在此基础上执行前面的基准测试, 通过csv文件可查看istio-telemetry的资源使用情况

[这里](./noop-report)提供了几个配置文件, 可用于控制rule的数量, 执行以下命令即可:

```shell
kubectl apply -f noop-1.yaml
```

切换rule数量:

```shell
kubectl delete -f noop-1.yaml
kubectl delete -f noop-2.yaml
```

...

如此类推

mixer性能与业务adapter的关系(以及qps等), 可配置adapter后再进行以上测试